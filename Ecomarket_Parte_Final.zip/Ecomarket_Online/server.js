const express = require('express');
const path = require('path');
const session = require('express-session');
require('dotenv').config();

// Importar rutas
const authRoutes = require('./routes/authRoutes');
const categoriaRoutes = require('./routes/categoriaRoutes');
const productoRoutes = require('./routes/productoRoutes');
const clienteRoutes = require('./routes/clienteRoutes');
const direccionRoutes = require('./routes/direccionRoutes');
const estadoPedidoRoutes = require('./routes/estadoPedidoRoutes');
const metodoPagoRoutes = require('./routes/metodoPagoRoutes');
const pedidosRoutes = require('./routes/pedidosRoutes');
const resenaRoutes = require('./routes/resenaRoutes');
const carritoRoutes = require('./routes/carritoRoutes');
const productRoutes = require('./routes/productRoutes'); 
const pedidoRoutes = require('./routes/pedidoRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api/clientes', clienteRoutes);
app.use('/api/direcciones', direccionRoutes);
app.use('/api/estados-pedido', estadoPedidoRoutes);
app.use('/api/metodos-pago', metodoPagoRoutes);

app.use('/api/resenas', resenaRoutes);
app.use('/api/carrito', carritoRoutes);
app.use('/api/products', productRoutes);

app.use('/api/pedidos', require('./routes/pedidoRoutes'));

// Configuración de sesión
app.use(session({
  secret: process.env.SESSION_SECRET || 'eco_market_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // Cambiar a true en producción con HTTPS
}));

// Rutas de API
app.use('/api/auth', authRoutes);
app.use('/api/categorias', categoriaRoutes);
app.use('/api/productos', productoRoutes);
app.use('/api/products', productRoutes);

// Ruta para el admin
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Ruta para login
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Ruta principal
app.get('/index', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Manejo de errores 404
app.use((req, res) => {
  res.status(404).json({ error: 'Ruta no encontrada' });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
  console.log(`Admin: http://localhost:${PORT}/admin`);
  console.log(`Login: http://localhost:${PORT}/login`);
  console.log(`Usuario: http://localhost:${PORT}/index`);
});