
const Pedido = require('../models/pedido'); // subir un nivel para ir a 'models'


module.exports = {
listAll: (req, res) => {
Pedido.getAll((err, pedidos) => {
if (err) return res.status(500).json({ error: 'Error al obtener los pedidos' });

        // Opcional: traer detalles de cada pedido
        const promises = pedidos.map(pedido => {
            return new Promise((resolve, reject) => {
                Pedido.getDetalles(pedido.id_pedido, (err, detalles) => {
                    if (err) reject(err);
                    pedido.detalles = detalles;
                    resolve();
                });
            });
        });

        Promise.all(promises)
            .then(() => res.json(pedidos))
            .catch(err => res.status(500).json({ error: 'Error al obtener los detalles' }));
    });
}


};