// controllers/productController.js
const Product = require('../models/product');

const productController = {
  async getAll(req, res) {
    try {
      const products = await Product.findAll();
      res.json({ success: true, data: products });
    } catch (err) {
      console.error('Error al obtener productos:', err);
      res.status(500).json({ success: false, message: 'Error al obtener productos' });
    }
  },

  async getById(req, res) {
    try {
      const id = parseInt(req.params.id, 10);
      if (Number.isNaN(id)) return res.status(400).json({ success: false, message: 'ID inválido' });

      const product = await Product.findById(id);
      if (!product) return res.status(404).json({ success: false, message: 'Producto no encontrado' });

      res.json({ success: true, data: product });
    } catch (err) {
      console.error('Error al obtener producto:', err);
      res.status(500).json({ success: false, message: 'Error al obtener producto' });
    }
  },

  async create(req, res) {
    try {
      const { nombre, id_categoria, descripcion, precio, stock, unidad_medida, imagen_url, es_organico } = req.body;
      if (!nombre || precio == null || stock == null) {
        return res.status(400).json({ success: false, message: 'Faltan campos requeridos (nombre, precio, stock)' });
      }
      const result = await Product.create({ nombre, id_categoria, descripcion, precio, stock, unidad_medida, imagen_url, es_organico });
      res.status(201).json({ success: true, data: { id: result.id } });
    } catch (err) {
      console.error('Error al crear producto:', err);
      res.status(500).json({ success: false, message: 'Error al crear producto' });
    }
  }
};

module.exports = productController;
