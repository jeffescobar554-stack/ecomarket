const pedidosModel = require('../models/pedidosModel');
const detallesModel = require('../models/detallesModel');

function crearPedido(req, res) {
  const { detalles, total } = req.body;

  if (!detalles || !detalles.length) {
    return res.status(400).json({ error: 'Carrito vacío' });
  }

  // crear pedido
  pedidosModel.crearPedido(total, (err, pedidoId) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Error al crear pedido' });
    }

    // insertar detalles secuencialmente
    let count = 0;
    for (let item of detalles) {
      detallesModel.agregarDetalle(pedidoId, item.id, item.cantidad, item.precio, (err2) => {
        if (err2) {
          console.error(err2);
          return res.status(500).json({ error: 'Error al agregar detalle' });
        }
        count++;
        if (count === detalles.length) {
          res.json({ success: true, pedidoId });
        }
      });
    }
  });
}

module.exports = { crearPedido };
