// js/cart-page.js
(function(){
  const CART_KEY = 'ecomarket_cart_v1';

  function readCart(){ try { return JSON.parse(localStorage.getItem(CART_KEY) || '[]'); } catch(e){ console.error(e); return []; } }
  function saveCart(c){ localStorage.setItem(CART_KEY, JSON.stringify(c)); updateSummary(); }
  function updateSummary(){
    const subtotal = readCart().reduce((s,it)=> s + (Number(it.precio||0) * Number(it.cantidad||0)), 0);
    document.getElementById('summary-subtotal').textContent = `$${subtotal.toFixed(2)}`;
    const count = readCart().reduce((s,i)=>s+Number(i.cantidad||0),0);
    // actualizar contador si existe en header
    const headerCount = document.getElementById('cart-count');
    if(headerCount) headerCount.textContent = count;
  }

  function createItemNode(item){
    const wrapper = document.createElement('div');
    wrapper.className = 'cart-item';
    wrapper.dataset.id = item.id;

    wrapper.innerHTML = `
      <img class="cart-thumb" src="${escapeHtml(item.imagen||'/images/default-product.png')}" alt="${escapeHtml(item.nombre)}" />
      <div class="cart-details">
        <div class="cart-name">${escapeHtml(item.nombre)}</div>
        <div class="cart-price">Unitario: $${Number(item.precio).toFixed(2)}</div>
        <div style="margin-top:.5rem;">
          <label>Cantidad:
            <input class="qty-input" type="number" min="1" value="${escapeHtml(item.cantidad)}" />
          </label>
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:.5rem;align-items:flex-end">
        <div class="cart-total">$${(Number(item.precio)*Number(item.cantidad)).toFixed(2)}</div>
        <button class="btn btn-danger btn-remove">Eliminar</button>
      </div>
    `;

    // qty listener
    wrapper.querySelector('.qty-input').addEventListener('change', (e) => {
      const val = Math.max(1, Number(e.target.value||1));
      const id = wrapper.dataset.id;
      const cart = readCart();
      const idx = cart.findIndex(i=>String(i.id)===String(id));
      if(idx>=0){ cart[idx].cantidad = val; saveCart(cart); renderCart(); }
    });

    // remove
    wrapper.querySelector('.btn-remove').addEventListener('click', () => {
      const id = wrapper.dataset.id;
      let cart = readCart();
      cart = cart.filter(i=>String(i.id)!==String(id));
      saveCart(cart);
      renderCart();
    });

    return wrapper;
  }

  function renderCart(){
    const root = document.getElementById('cart-root');
    const cart = readCart();
    root.innerHTML = '';
    if(!cart.length){
      root.innerHTML = `<div class="empty-state"><h3>Tu carrito está vacío</h3><p>Agrega productos para comenzar.</p></div>`;
      document.getElementById('cart-actions').style.display = 'none';
      updateSummary();
      return;
    }
    document.getElementById('cart-actions').style.display = 'flex';

    cart.forEach(item => {
      root.appendChild(createItemNode(item));
    });

    updateSummary();
  }

  function escapeHtml(str){
    if(str===undefined || str===null) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  // acciones botones
  document.addEventListener('DOMContentLoaded', () => {
    renderCart();
    document.getElementById('btn-clear').addEventListener('click', () => {
      if(!confirm('¿Vaciar el carrito?')) return;
      saveCart([]);
      renderCart();
    });

document.getElementById('btn-checkout').addEventListener('click', async () => {
  const cart = readCart();
  if(!cart.length) { alert('El carrito está vacío.'); return; }

  const total = cart.reduce((s,it)=> s + Number(it.precio||0)*Number(it.cantidad||0), 0).toFixed(2);
  if(!confirm(`Total: $${total}\n\n¿Deseas confirmar la compra?`)) return;

  try {
    const res = await fetch('/api/pedidos', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({
        total: total,
        detalles: cart.map(i => ({id: i.id, cantidad: i.cantidad, precio: i.precio}))
      })
    });

    const data = await res.json();
    if(!res.ok) throw new Error(data.error || 'Error al crear pedido');

    saveCart([]);
    renderCart();
    alert('Compra realizada con éxito. Gracias por comprar en ECOMARKET.');
  } catch(err) {
    console.error(err);
    alert('Error al procesar la compra: ' + err.message);
  }
});

  });
})();
