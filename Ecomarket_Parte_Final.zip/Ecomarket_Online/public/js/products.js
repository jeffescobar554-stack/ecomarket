// public/js/products.js
document.addEventListener('DOMContentLoaded', () => {
  const listEl = document.getElementById('product-list');

  async function fetchProducts() {
    try {
      const res = await fetch('/api/products');
      if (!res.ok) throw new Error('Error al obtener productos');
      const json = await res.json();
      if (!json.success) throw new Error(json.message || 'Respuesta no exitosa');
      renderProducts(json.data);
    } catch (err) {
      console.error(err);
      listEl.innerHTML = `<p class="error">No se pudieron cargar los productos. Intenta de nuevo más tarde.</p>`;
    }
  }

  function renderProducts(products) {
    if (!products || products.length === 0) {
      listEl.innerHTML = '<p>No hay productos disponibles.</p>';
      return;
    }

    // Renderizamos las tarjetas; NO añadimos listeners aquí (delegación en cart.js)
    listEl.innerHTML = products.map(p => productCardHTML(p)).join('');
  }

  function productCardHTML(p) {
    const imageSrc = p.imagen && p.imagen.trim() ? p.imagen : '/images/default-product.png';
    const desc = p.descripcion ? escapeHtml(p.descripcion).slice(0, 120) + (p.descripcion.length > 120 ? '...' : '') : '';
    const unidad = p.unidad_medida ? ` / ${p.unidad_medida}` : '';
    // Nota: guardamos datos "raw" en data-* (solo escapamos comillas)
    const safeNameAttr = (p.nombre || '').replace(/"/g, '&quot;');
    return `
      <article class="product-card">
        <img src="${imageSrc}" alt="${escapeHtml(p.nombre)}" class="product-image"/>
        <div class="product-info">
          <h3 class="product-name">${escapeHtml(p.nombre)}</h3>
          <p class="product-desc">${desc}</p>
          <p class="product-price">$${Number(p.precio).toFixed(2)}${unidad}</p>
          <p class="product-stock">${p.stock > 0 ? 'Disponible: ' + p.stock : '<span class="out">Agotado</span>'}</p>
          <div class="product-actions">
            <button class="btn-add"
                    data-id="${p.id}"
                    data-nombre="${safeNameAttr}"
                    data-precio="${Number(p.precio).toFixed(2)}"
                    data-imagen="${imageSrc}">
              Agregar
            </button>
          </div>
        </div>
      </article>
    `;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  fetchProducts();
});
