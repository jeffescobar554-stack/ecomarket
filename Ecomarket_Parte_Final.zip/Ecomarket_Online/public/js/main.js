// public/js/main.js

document.addEventListener("DOMContentLoaded", () => {
    const authBtn = document.getElementById("auth-btn");

    if (authBtn) {
        authBtn.addEventListener("click", () => {
            window.location.href = "/login.html";
        });
    }
});
