// public/js/cart.js  (parche sugerido)
document.addEventListener('DOMContentLoaded', () => {
  const cartOverlay = document.getElementById('cart-modal'); // overlay
  const cartContentWrapper = cartOverlay ? cartOverlay.querySelector('.modal-content') : null;
  const cartToggle = document.getElementById('cart-toggle');
  const cartCountEl = document.getElementById('cart-count');

  if (!cartOverlay || !cartToggle || !cartCountEl) {
    console.warn('Elementos del carrito no encontrados: verifica #cart-modal, #cart-toggle o #cart-count.');
    return;
  }

  // si falta .modal-content dentro del overlay, créalo (fallback)
  let contentWrapper = cartContentWrapper;
  if (!contentWrapper) {
    contentWrapper = document.createElement('div');
    contentWrapper.className = 'modal-content';
    cartOverlay.appendChild(contentWrapper);
    console.info('Se creó .modal-content dentro de #cart-modal (fallback).');
  }

  const CART_KEY = 'ecomarket_cart_v1';

  function readCart() {
    try { return JSON.parse(localStorage.getItem(CART_KEY) || '[]'); }
    catch (e) { console.error('Error parseando carrito', e); return []; }
  }
  function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
    updateCartCount();
  }
  function updateCartCount() {
    const cart = readCart();
    const totalQty = cart.reduce((s, it) => s + Number(it.cantidad || 0), 0);
    cartCountEl.textContent = totalQty;
  }

  function addToCart(product) {
    const cart = readCart();
    const id = String(product.id);
    const idx = cart.findIndex(i => String(i.id) === id);
    if (idx >= 0) {
      cart[idx].cantidad = Number(cart[idx].cantidad || 0) + Number(product.cantidad || 1);
    } else {
      cart.push({
        id: id,
        nombre: product.nombre || 'Producto',
        precio: Number(product.precio || 0),
        cantidad: Number(product.cantidad || 1),
        imagen: product.imagen || ''
      });
    }
    saveCart(cart);
    console.log('Producto agregado. Carrito ahora:', readCart());
  }

  function renderCartModal() {
    const cart = readCart();
    const wrapper = document.createElement('div');
    wrapper.className = 'cart-content';

    if (!cart.length) {
      wrapper.innerHTML = `
        <div style="padding:1.5rem; text-align:center;">
          <h3>Tu carrito está vacío</h3>
          <p>Agrega productos para comenzar.</p>
        </div>
      `;
      contentWrapper.innerHTML = '';
      contentWrapper.appendChild(wrapper);
      return;
    }

    const subtotal = cart.reduce((s, it) => s + (Number(it.precio) * Number(it.cantidad)), 0);
    wrapper.innerHTML = `
      <div class="cart-items" style="max-height:60vh; overflow:auto; padding:1rem;">
        ${cart.map(it => `
          <div class="cart-item" data-id="${escapeHtml(it.id)}" style="display:flex; gap:1rem; align-items:center; margin-bottom:1rem;">
            <img src="${escapeHtml(it.imagen || '/images/default-product.png')}" alt="${escapeHtml(it.nombre)}" style="width:64px; height:64px; object-fit:cover; border-radius:6px;">
            <div style="flex:1;">
              <strong class="cart-item-name">${escapeHtml(it.nombre)}</strong>
              <div style="margin-top:.25rem;">
                <label>Cantidad:
                  <input type="number" min="1" value="${escapeHtml(it.cantidad)}" class="cart-qty" style="width:72px; margin-left:.5rem;">
                </label>
              </div>
              <div style="margin-top:.25rem;">Precio unitario: $${Number(it.precio).toFixed(2)}</div>
              <div style="margin-top:.25rem;">Total: $${(Number(it.precio) * Number(it.cantidad)).toFixed(2)}</div>
            </div>
            <button class="btn-remove" style="background:transparent; border:none; color:#c00; font-weight:bold; cursor:pointer;">Eliminar</button>
          </div>
        `).join('')}
      </div>
      <div style="padding:1rem; border-top:1px solid #eee; display:flex; justify-content:space-between; align-items:center;">
        <div>
          <strong>Subtotal:</strong> $${subtotal.toFixed(2)}
        </div>
        <div style="display:flex; gap:.5rem;">
          <button id="btn-clear-cart" class="cta-button">Vaciar</button>
          <button id="btn-checkout" class="cta-button">Pagar</button>
        </div>
      </div>
    `;

    contentWrapper.innerHTML = '';
    contentWrapper.appendChild(wrapper);

    // listeners
    contentWrapper.querySelectorAll('.cart-qty').forEach(input => {
      input.addEventListener('change', (e) => {
        const parent = e.target.closest('.cart-item');
        const id = parent.dataset.id;
        const qty = Math.max(1, Number(e.target.value || 1));
        const cart = readCart();
        const idx = cart.findIndex(i => String(i.id) === String(id));
        if (idx >= 0) {
          cart[idx].cantidad = qty;
          saveCart(cart);
          renderCartModal();
        }
      });
    });

    contentWrapper.querySelectorAll('.btn-remove').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const parent = e.target.closest('.cart-item');
        const id = parent.dataset.id;
        let cart = readCart();
        cart = cart.filter(i => String(i.id) !== String(id));
        saveCart(cart);
        renderCartModal();
      });
    });

    const clearBtn = contentWrapper.querySelector('#btn-clear-cart');
    if (clearBtn) clearBtn.addEventListener('click', () => {
      if (!confirm('¿Vaciar el carrito?')) return;
      saveCart([]);
      renderCartModal();
    });

    const checkoutBtn = contentWrapper.querySelector('#btn-checkout');
    if (checkoutBtn) checkoutBtn.addEventListener('click', () => {
      handleCheckout();
    });
  }

  async function handleCheckout() {
    const cart = readCart();
    if (!cart.length) return alert('El carrito está vacío.');

    const cliente_id = window.__ECOMARKET_CLIENT_ID || null;
    if (!cliente_id) {
      if (!confirm('No estás identificado. ¿Deseas continuar como invitado? (Recomendado: iniciar sesión)')) return;
    }

    const today = new Date();
    const body = {
      cliente_id,
      fecha: today.toISOString().slice(0,10),
      total: cart.reduce((s, it) => s + (Number(it.precio) * Number(it.cantidad)), 0).toFixed(2),
      tipo_suscripcion: 'ninguna',
      detalles: cart.map(it => ({
        producto_id: it.id,
        cantidad: Number(it.cantidad),
        precio_unitario: Number(it.precio)
      }))
    };

    try {
      const res = await fetch('/api/pedidos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || 'Error al crear pedido');
      saveCart([]);
      alert('Pedido creado correctamente. ID pedido: ' + (json.data && json.data.id ? json.data.id : '—'));
      renderCartModal();
      cartOverlay.classList.remove('open');
    } catch (err) {
      console.error(err);
      alert('Error al procesar el pedido: ' + (err.message || err));
    }
  }

  // delegación global - detectar botones 'Agregar' de manera robusta
  document.body.addEventListener('click', (e) => {
    const addBtn = e.target.closest('button.btn-add, .btn-add'); // acepta <button> o elemento con clase
    if (!addBtn) return;
    // DEBUG: ver si el click llegó
    console.log('Click en btn-add detectado, dataset:', addBtn.dataset);

    const id = addBtn.dataset.id || addBtn.getAttribute('data-id');
    const name = (addBtn.dataset.nombre || addBtn.dataset.name ||
                 addBtn.closest('.product-card')?.querySelector('.product-name')?.textContent || 'Producto');
    const priceRaw = addBtn.dataset.precio || addBtn.dataset.price || addBtn.closest('.product-card')?.querySelector('.product-price')?.textContent || '0';
    const price = parseFloat(String(priceRaw).replace(/[^0-9\.,]/g,'').replace(',','.')) || 0;
    const img = addBtn.dataset.imagen || addBtn.dataset.image || addBtn.closest('.product-card')?.querySelector('img')?.getAttribute('src') || '';
    addToCart({ id, nombre: String(name).trim(), precio: price, cantidad: 1, imagen: img });

    // opcional: abrir el carrito al agregar (comentarlo si no lo quieres)
    // cartOverlay.classList.add('open');
    // renderCartModal();
  });

// -- parche rápido para debugging + robustez --
cartToggle.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  const overlay = cartOverlay;
  overlay.classList.toggle('open');
  console.log('Carrito toggle. abierto?', overlay.classList.contains('open'), 'contenido actual:', readCart());
  // asegurarse de que exista wrapper y tenga estilo visible
  if (!contentWrapper) {
    contentWrapper = overlay.querySelector('.modal-content');
    if (!contentWrapper) {
      contentWrapper = document.createElement('div');
      contentWrapper.className = 'modal-content';
      overlay.appendChild(contentWrapper);
      console.info('Fallback: creado .modal-content dinámicamente.');
    }
  }
  // fuerza estilos mínimos para evitar CSS rompedor
  contentWrapper.style.zIndex = 10000;
  contentWrapper.style.maxHeight = '90vh';
  contentWrapper.style.overflow = 'auto';
  contentWrapper.style.display = 'block';

  if (overlay.classList.contains('open')) {
    // log antes del render
    console.log('Llamando a renderCartModal() — cart length:', readCart().length);
    renderCartModal();
    // después del render, comprueba si el contenido quedó vacío
    setTimeout(() => {
      const html = contentWrapper.innerHTML && contentWrapper.innerHTML.trim();
      console.log('post-render content length:', html ? html.length : 0, 'contains .cart-items?', !!contentWrapper.querySelector('.cart-items'));
      if (!html) {
        contentWrapper.innerHTML = '<div style="padding:1.5rem; text-align:center;">Error: renderCartModal no inyectó contenido.</div>';
      }
    }, 80);
  }
});

// cerrar al presionar ESC
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && cartOverlay.classList.contains('open')) {
    cartOverlay.classList.remove('open');
  }
});

  cartOverlay.addEventListener('click', (e) => {
    if (e.target === cartOverlay) cartOverlay.classList.remove('open');
  });

  function escapeHtml(str) {
    if (str === undefined || str === null) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  updateCartCount();
});

document.getElementById('btn-checkout').addEventListener('click', async () => {
  const cart = JSON.parse(localStorage.getItem('ecomarket_cart_v1') || '[]');
  if (!cart.length) return alert('Carrito vacío');

  const total = cart.reduce((sum, item) => sum + item.precio * item.cantidad, 0);

  const cliente_id = window.__ECOMARKET_CLIENT_ID || null; // si tienes login
  const metodo_pago = 'Efectivo'; // puedes hacer selector de método

  try {
    const res = await fetch('/api/pedidos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cliente_id, total, metodo_pago, detalles: cart })
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.message || 'Error');

    alert(`Pedido creado correctamente. ID: ${json.pedidoId}`);
    localStorage.removeItem('ecomarket_cart_v1'); // limpiar carrito
    window.location.href = 'index.html'; // opcional volver al inicio
  } catch (err) {
    console.error(err);
    alert('Error al crear pedido: ' + err.message);
  }
});
