// Funcionalidades del carrito de compras

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar carrito
    initCart();
    
    // Si estamos en la página del carrito, cargar los items
    if (document.querySelector('.cart-page')) {
        loadCartItems();
    }
});

function initCart() {
    // Inicializar carrito en localStorage si no existe
    if (!localStorage.getItem('cart')) {
        localStorage.setItem('cart', JSON.stringify([]));
    }
    
    // Actualizar contador del carrito
    updateCartCount();
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartCountElements = document.querySelectorAll('.cart-count');
    
    cartCountElements.forEach(element => {
        element.textContent = cart.reduce((total, item) => total + item.quantity, 0);
    });
}

function addToCart(product) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    // Verificar si el producto ya está en el carrito
    const existingItemIndex = cart.findIndex(item => item.id === product.id);
    
    if (existingItemIndex !== -1) {
        // Actualizar cantidad
        cart[existingItemIndex].quantity += product.quantity;
    } else {
        // Agregar nuevo producto
        cart.push({
            id: product.id,
            nombre: product.nombre,
            precio: product.precio,
            imagen_url: product.imagen_url,
            unidad_medida: product.unidad_medida,
            quantity: product.quantity,
            stock: product.stock
        });
    }
    
    // Guardar en localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Actualizar contador
    updateCartCount();
    
    // Mostrar notificación
    showNotification('Producto agregado al carrito');
}

function loadCartItems() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartItemsContainer = document.getElementById('cart-items');
    const cartTotalElement = document.getElementById('cart-total');
    const cartSubtotalElement = document.getElementById('cart-subtotal');
    const cartShippingElement = document.getElementById('cart-shipping');
    
    if (cartItemsContainer) {
        if (cart.length === 0) {
            cartItemsContainer.innerHTML = `
                <div class="empty-cart">
                    <i class="fas fa-shopping-cart"></i>
                    <h3>Tu carrito está vacío</h3>
                    <p>Agrega productos orgánicos para comenzar tu compra</p>
                    <a href="productos.html" class="btn btn-primary">Ver productos</a>
                </div>
            `;
            return;
        }
        
        let subtotal = 0;
        
        cartItemsContainer.innerHTML = cart.map(item => {
            const itemTotal = item.precio * item.quantity;
            subtotal += itemTotal;
            
            return `
                <div class="cart-item" data-id="${item.id}">
                    <div class="cart-item-image">
                        <img src="${item.imagen_url}" alt="${item.nombre}">
                    </div>
                    <div class="cart-item-info">
                        <h3>${item.nombre}</h3>
                        <p class="item-price">$${item.precio.toFixed(2)} / ${item.unidad_medida}</p>
                    </div>
                    <div class="cart-item-quantity">
                        <button class="quantity-btn minus" data-id="${item.id}">-</button>
                        <input type="number" class="quantity-input" value="${item.quantity}" min="1" max="${item.stock}" data-id="${item.id}">
                        <button class="quantity-btn plus" data-id="${item.id}">+</button>
                    </div>
                    <div class="cart-item-total">
                        $${itemTotal.toFixed(2)}
                    </div>
                    <button class="cart-item-remove" data-id="${item.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
        }).join('');
        
        // Calcular totales
        const shipping = subtotal > 500 ? 0 : 50; // Envío gratis sobre $500
        const total = subtotal + shipping;
        
        if (cartSubtotalElement) cartSubtotalElement.textContent = `$${subtotal.toFixed(2)}`;
        if (cartShippingElement) cartShippingElement.textContent = shipping === 0 ? 'Gratis' : `$${shipping.toFixed(2)}`;
        if (cartTotalElement) cartTotalElement.textContent = `$${total.toFixed(2)}`;
        
        // Agregar event listeners
        addCartEventListeners();
    }
}

function addCartEventListeners() {
    // Botones de cantidad
    document.querySelectorAll('.quantity-btn.minus').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = this.getAttribute('data-id');
            updateCartQuantity(productId, -1);
        });
    });
    
    document.querySelectorAll('.quantity-btn.plus').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = this.getAttribute('data-id');
            updateCartQuantity(productId, 1);
        });
    });
    
    // Inputs de cantidad
    document.querySelectorAll('.quantity-input').forEach(input => {
        input.addEventListener('change', function() {
            const productId = this.getAttribute('data-id');
            const newQuantity = parseInt(this.value);
            updateCartQuantity(productId, 0, newQuantity);
        });
    });
    
    // Botones de eliminar
    document.querySelectorAll('.cart-item-remove').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = this.getAttribute('data-id');
            removeFromCart(productId);
        });
    });
}

function updateCartQuantity(productId, change, newQuantity = null) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const itemIndex = cart.findIndex(item => item.id == productId);
    
    if (itemIndex !== -1) {
        if (newQuantity !== null) {
            cart[itemIndex].quantity = Math.min(Math.max(newQuantity, 1), cart[itemIndex].stock);
        } else {
            cart[itemIndex].quantity = Math.min(Math.max(cart[itemIndex].quantity + change, 1), cart[itemIndex].stock);
        }
        
        // Si la cantidad es 0, eliminar el producto
        if (cart[itemIndex].quantity === 0) {
            cart.splice(itemIndex, 1);
        }
        
        localStorage.setItem('cart', JSON.stringify(cart));
        loadCartItems();
        updateCartCount();
    }
}

function removeFromCart(productId) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const updatedCart = cart.filter(item => item.id != productId);
    
    localStorage.setItem('cart', JSON.stringify(updatedCart));
    loadCartItems();
    updateCartCount();
    
    showNotification('Producto eliminado del carrito');
}

function showNotification(message) {
    // Crear notificación
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span>${message}</span>
    `;
    
    // Estilos para la notificación
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background-color: var(--primary-color);
        color: white;
        padding: 15px 20px;
        border-radius: 5px;
        display: flex;
        align-items: center;
        gap: 10px;
        box-shadow: var(--shadow);
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Remover después de 3 segundos
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Estilos para las animaciones
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);