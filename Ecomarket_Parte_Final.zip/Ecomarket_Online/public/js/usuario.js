// Funcionalidades para la parte de usuario

document.addEventListener('DOMContentLoaded', function() {
    // Verificar si estamos en la página de productos
    if (document.querySelector('.products-page')) {
        loadProducts();
        initProductFilters();
    }
    
    // Verificar sesión de usuario
    checkUserAuth();
});

function checkUserAuth() {
    const isUserLoggedIn = localStorage.getItem('userLoggedIn');
    const userPages = ['usuario/index.html', 'usuario/productos.html', 'usuario/carrito.html', 'usuario/pedidos.html', 'usuario/perfil.html'];
    
    const currentPage = window.location.pathname.split('/').pop();
    
    if (!isUserLoggedIn && userPages.includes(currentPage)) {
        window.location.href = '../login.html';
    }
}

function loadProducts() {
    // Simulación de productos
    const products = [
        {
            id: 1,
            nombre: 'Manzanas Orgánicas',
            descripcion: 'Manzanas cultivadas sin pesticidas químicos, perfectas para snacks saludables.',
            precio: 45.50,
            stock: 100,
            unidad_medida: 'kg',
            imagen_url: '../assets/manzanas.jpg',
            ingredientes: 'Manzanas orgánicas',
            categoria: 'frutas'
        },
        {
            id: 2,
            nombre: 'Lechuga Romana',
            descripcion: 'Lechuga fresca cultivada localmente, ideal para ensaladas.',
            precio: 25.00,
            stock: 50,
            unidad_medida: 'pieza',
            imagen_url: '../assets/lechuga.jpg',
            ingredientes: 'Lechuga romana orgánica',
            categoria: 'verduras'
        },
        {
            id: 3,
            nombre: 'Arroz Integral',
            descripcion: 'Arroz integral de grano entero, rico en fibra y nutrientes.',
            precio: 60.00,
            stock: 200,
            unidad_medida: 'kg',
            imagen_url: '../assets/arroz.jpg',
            ingredientes: 'Arroz integral orgánico',
            categoria: 'granos'
        }
    ];
    
    const productsGrid = document.getElementById('products-grid');
    if (productsGrid) {
        productsGrid.innerHTML = products.map(product => `
            <div class="product-card" data-id="${product.id}">
                <div class="product-image">
                    <img src="${product.imagen_url}" alt="${product.nombre}">
                    ${product.stock < 10 ? '<span class="stock-badge low-stock">Poco stock</span>' : ''}
                </div>
                <div class="product-info">
                    <h3>${product.nombre}</h3>
                    <p class="product-description">${product.descripcion.substring(0, 100)}...</p>
                    <div class="product-footer">
                        <div class="product-price">$${product.precio.toFixed(2)} / ${product.unidad_medida}</div>
                        <button class="btn btn-primary add-to-cart-btn" data-id="${product.id}">
                            <i class="fas fa-cart-plus"></i> Agregar
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
        
        // Agregar event listeners a los botones
        document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const productId = this.getAttribute('data-id');
                const product = products.find(p => p.id == productId);
                addToCart(product);
            });
        });
        
        // Agregar event listeners para ver detalles del producto
        document.querySelectorAll('.product-card').forEach(card => {
            card.addEventListener('click', function(e) {
                if (!e.target.classList.contains('add-to-cart-btn')) {
                    const productId = this.getAttribute('data-id');
                    const product = products.find(p => p.id == productId);
                    showProductDetails(product);
                }
            });
        });
    }
}

function initProductFilters() {
    const applyFiltersBtn = document.getElementById('apply-filters');
    const clearFiltersBtn = document.getElementById('clear-filters');
    
    if (applyFiltersBtn) {
        applyFiltersBtn.addEventListener('click', function() {
            // Lógica para aplicar filtros
            console.log('Aplicando filtros...');
        });
    }
    
    if (clearFiltersBtn) {
        clearFiltersBtn.addEventListener('click', function() {
            // Limpiar todos los filtros
            document.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
            document.querySelectorAll('input[type="radio"]').forEach(rb => rb.checked = false);
            document.querySelector('.price-slider').value = 500;
        });
    }
}

function showProductDetails(product) {
    const modal = document.getElementById('product-modal');
    const modalTitle = document.getElementById('product-modal-title');
    const modalImg = document.getElementById('product-modal-img');
    const modalPrice = document.getElementById('product-modal-price');
    const modalDescription = document.getElementById('product-modal-description');
    const modalIngredients = document.getElementById('product-modal-ingredients');
    const modalStock = document.getElementById('product-modal-stock');
    const modalUnit = document.getElementById('product-modal-unit');
    
    // Llenar datos del modal
    modalTitle.textContent = product.nombre;
    modalImg.src = product.imagen_url;
    modalImg.alt = product.nombre;
    modalPrice.textContent = `$${product.precio.toFixed(2)} / ${product.unidad_medida}`;
    modalDescription.textContent = product.descripcion;
    modalIngredients.textContent = product.ingredientes;
    modalStock.textContent = product.stock;
    modalUnit.textContent = product.unidad_medida;
    
    // Configurar botón de agregar al carrito
    const addToCartBtn = document.getElementById('add-to-cart-modal');
    addToCartBtn.onclick = function() {
        const quantity = parseInt(document.getElementById('product-quantity').value);
        const productToAdd = {...product, quantity};
        addToCart(productToAdd);
        modal.classList.remove('active');
    };
    
    // Mostrar modal
    modal.classList.add('active');
    
    // Configurar controles de cantidad
    const minusBtn = document.querySelector('.quantity-btn.minus');
    const plusBtn = document.querySelector('.quantity-btn.plus');
    const quantityInput = document.getElementById('product-quantity');
    
    minusBtn.onclick = function() {
        let value = parseInt(quantityInput.value);
        if (value > 1) {
            quantityInput.value = value - 1;
        }
    };
    
    plusBtn.onclick = function() {
        let value = parseInt(quantityInput.value);
        if (value < product.stock) {
            quantityInput.value = value + 1;
        }
    };
}

// Función para agregar al carrito (se implementará en carrito.js)
function addToCart(product) {
    // Esta función será llamada desde carrito.js
    console.log('Agregando al carrito:', product);
}