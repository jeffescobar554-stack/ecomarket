class AdminApp {
    constructor() {
        this.currentSection = 'categorias';
        this.categorias = [];
        this.productos = [];
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadCategorias();
        this.loadProductos();
        this.loadPedidos();
    }

    setupEventListeners() {
        // Navegación entre secciones
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchSection(e.target.dataset.section);
            });
        });

        // Botones de agregar
        document.getElementById('addCategoriaBtn').addEventListener('click', () => {
            this.openCategoriaModal();
        });

        document.getElementById('addProductoBtn').addEventListener('click', () => {
            this.openProductoModal();
        });

        // Modales
        document.querySelectorAll('.close').forEach(closeBtn => {
            closeBtn.addEventListener('click', () => {
                this.closeModals();
            });
        });

        // Formularios
        document.getElementById('categoriaForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveCategoria();
        });

        document.getElementById('productoForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveProducto();
        });

        // Cerrar modal al hacer click fuera
        window.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModals();
            }
        });
    }

    switchSection(section) {
        // Actualizar botones de navegación
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-section="${section}"]`).classList.add('active');

        // Actualizar secciones
        document.querySelectorAll('.section').forEach(sec => {
            sec.classList.remove('active');
        });
        document.getElementById(`${section}-section`).classList.add('active');

        this.currentSection = section;
    }

    closeModals() {
        document.getElementById('categoriaModal').style.display = 'none';
        document.getElementById('productoModal').style.display = 'none';
    }

    // Métodos para Categorías
    async loadCategorias() {
        try {
            const response = await Auth.makeAuthenticatedRequest('/api/categorias');
            if (response) {
                this.categorias = await response.json();
                this.renderCategorias();
            }
        } catch (error) {
            console.error('Error cargando categorías:', error);
        }
    }

    renderCategorias() {
        const container = document.getElementById('categorias-list');
        if (this.categorias.length === 0) {
            container.innerHTML = '<p>No hay categorías registradas.</p>';
            return;
        }

        const table = `
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    ${this.categorias.map(cat => `
                        <tr>
                            <td>${cat.id_categoria}</td>
                            <td>${cat.nombre}</td>
                            <td>${cat.descripcion || '-'}</td>
                            <td>
                                <button class="btn-edit" onclick="adminApp.editCategoria(${cat.id_categoria})">Editar</button>
                                <button class="btn-delete" onclick="adminApp.deleteCategoria(${cat.id_categoria})">Eliminar</button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
        container.innerHTML = table;
    }

    openCategoriaModal(categoria = null) {
        const modal = document.getElementById('categoriaModal');
        const title = document.getElementById('categoriaModalTitle');
        const form = document.getElementById('categoriaForm');

        if (categoria) {
            title.textContent = 'Editar Categoría';
            document.getElementById('categoriaId').value = categoria.id_categoria;
            document.getElementById('categoriaNombre').value = categoria.nombre;
            document.getElementById('categoriaDescripcion').value = categoria.descripcion || '';
            document.getElementById('categoriaImagen').value = categoria.imagen_url || '';
        } else {
            title.textContent = 'Agregar Categoría';
            form.reset();
        }

        modal.style.display = 'block';
    }

    async saveCategoria() {
        const id = document.getElementById('categoriaId').value;
        const formData = {
            nombre: document.getElementById('categoriaNombre').value,
            descripcion: document.getElementById('categoriaDescripcion').value,
            imagen_url: document.getElementById('categoriaImagen').value
        };

        try {
            const url = id ? `/api/categorias/${id}` : '/api/categorias';
            const method = id ? 'PUT' : 'POST';

            const response = await Auth.makeAuthenticatedRequest(url, {
                method: method,
                body: JSON.stringify(formData)
            });

            if (response && response.ok) {
                this.closeModals();
                this.loadCategorias();
            } else {
                alert('Error guardando la categoría');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error guardando la categoría');
        }
    }

    editCategoria(id) {
        const categoria = this.categorias.find(cat => cat.id_categoria === id);
        if (categoria) {
            this.openCategoriaModal(categoria);
        }
    }

    async deleteCategoria(id) {
        if (!confirm('¿Estás seguro de que quieres eliminar esta categoría?')) {
            return;
        }

        try {
            const response = await Auth.makeAuthenticatedRequest(`/api/categorias/${id}`, {
                method: 'DELETE'
            });

            if (response && response.ok) {
                this.loadCategorias();
            } else {
                alert('Error eliminando la categoría');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error eliminando la categoría');
        }
    }

    // Métodos para Productos
    async loadProductos() {
        try {
            const response = await Auth.makeAuthenticatedRequest('/api/productos');
            if (response) {
                this.productos = await response.json();
                this.renderProductos();
            }
        } catch (error) {
            console.error('Error cargando productos:', error);
        }
    }

// En public/js/admin.js - modificar renderProductos
renderProductos() {
    const container = document.getElementById('productos-list');
    
    // Filtrar productos activos (por si acaso)
    const productosActivos = this.productos.filter(prod => prod.activo !== false);
    
    if (productosActivos.length === 0) {
        container.innerHTML = '<p>No hay productos registrados.</p>';
        return;
    }

    const table = `
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Categoría</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Orgánico</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                ${productosActivos.map(prod => `
                    <tr>
                        <td>${prod.id_producto}</td>
                        <td>${prod.nombre}</td>
                        <td>${prod.categoria_nombre}</td>
                        <td>$${prod.precio}</td>
                        <td>${prod.stock} ${prod.unidad_medida}</td>
                        <td>${prod.es_organico ? 'Sí' : 'No'}</td>
                        <td>${prod.activo ? 'Activo' : 'Inactivo'}</td>
                        <td>
                            <button class="btn-edit" onclick="adminApp.editProducto(${prod.id_producto})">Editar</button>
                            <button class="btn-delete" onclick="adminApp.deleteProducto(${prod.id_producto})">Eliminar</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    container.innerHTML = table;
}

    openProductoModal(producto = null) {
        const modal = document.getElementById('productoModal');
        const title = document.getElementById('productoModalTitle');
        const categoriaSelect = document.getElementById('productoCategoria');

        // Llenar select de categorías
        categoriaSelect.innerHTML = this.categorias.map(cat => 
            `<option value="${cat.id_categoria}">${cat.nombre}</option>`
        ).join('');

        if (producto) {
            title.textContent = 'Editar Producto';
            document.getElementById('productoId').value = producto.id_producto;
            document.getElementById('productoNombre').value = producto.nombre;
            document.getElementById('productoCategoria').value = producto.id_categoria;
            document.getElementById('productoPrecio').value = producto.precio;
            document.getElementById('productoStock').value = producto.stock;
            document.getElementById('productoUnidad').value = producto.unidad_medida;
            document.getElementById('productoDescripcion').value = producto.descripcion;
            document.getElementById('productoImagen').value = producto.imagen_url || '';
            document.getElementById('productoOrganico').checked = producto.es_organico;
            document.getElementById('productoIngredientes').value = producto.ingredientes || '';
            document.getElementById('productoNutricional').value = producto.informacion_nutricional || '';
        } else {
            title.textContent = 'Agregar Producto';
            document.getElementById('productoForm').reset();
        }

        modal.style.display = 'block';
    }

    async saveProducto() {
        const id = document.getElementById('productoId').value;
        const formData = {
            nombre: document.getElementById('productoNombre').value,
            id_categoria: document.getElementById('productoCategoria').value,
            precio: parseFloat(document.getElementById('productoPrecio').value),
            stock: parseInt(document.getElementById('productoStock').value),
            unidad_medida: document.getElementById('productoUnidad').value,
            descripcion: document.getElementById('productoDescripcion').value,
            imagen_url: document.getElementById('productoImagen').value,
            es_organico: document.getElementById('productoOrganico').checked,
            ingredientes: document.getElementById('productoIngredientes').value,
            informacion_nutricional: document.getElementById('productoNutricional').value
        };

        try {
            const url = id ? `/api/productos/${id}` : '/api/productos';
            const method = id ? 'PUT' : 'POST';

            const response = await Auth.makeAuthenticatedRequest(url, {
                method: method,
                body: JSON.stringify(formData)
            });

            if (response && response.ok) {
                this.closeModals();
                this.loadProductos();
            } else {
                alert('Error guardando el producto');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error guardando el producto');
        }
    }

    editProducto(id) {
        const producto = this.productos.find(prod => prod.id_producto === id);
        if (producto) {
            this.openProductoModal(producto);
        }
    }

// En public/js/admin.js - modificar el método deleteProducto
async deleteProducto(id) {
    if (!confirm('¿Estás seguro de que quieres eliminar este producto?')) {
        return;
    }

    try {
        const response = await Auth.makeAuthenticatedRequest(`/api/productos/${id}`, {
            method: 'DELETE'
        });

        if (response && response.ok) {
            // Recargar la lista de productos después de eliminar
            await this.loadProductos();
            alert('Producto eliminado exitosamente');
        } else {
            const errorData = await response.json();
            alert('Error eliminando el producto: ' + (errorData.error || 'Error desconocido'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error eliminando el producto: ' + error.message);
    }
}

// Y también mejorar el método loadProductos para manejar errores
async loadProductos() {
    try {
        const response = await Auth.makeAuthenticatedRequest('/api/productos');
        if (response && response.ok) {
            this.productos = await response.json();
            this.renderProductos();
        } else {
            console.error('Error cargando productos:', response.status);
        }
    } catch (error) {
        console.error('Error cargando productos:', error);
        alert('Error cargando los productos: ' + error.message);
    }
}

// Cargar pedidos
async loadPedidos() {
    try {
        const response = await Auth.makeAuthenticatedRequest('/api/pedidos');
        if (response && response.ok) {
            this.pedidos = await response.json();
            this.renderPedidos();
        } else {
            console.error('Error cargando pedidos:', response.status);
        }
    } catch (error) {
        console.error('Error cargando pedidos:', error);
    }
}

// Renderizar pedidos en tabla
renderPedidos() {
    const container = document.getElementById('pedidos-list');
    if (!this.pedidos || this.pedidos.length === 0) {
        container.innerHTML = '<p>No hay pedidos registrados.</p>';
        return;
    }

    const table = `
        <table>
            <thead>
                <tr>
                    <th>ID Pedido</th>
                    <th>Cliente</th>
                    <th>Fecha</th>
                    <th>Estado</th>
                    <th>Detalles</th>
                </tr>
            </thead>
            <tbody>
                ${this.pedidos.map(p => `
                    <tr>
                        <td>${p.id_pedido}</td>
                        <td>${p.cliente_nombre || 'Sin nombre'}</td>
                        <td>${new Date(p.fecha).toLocaleString()}</td>
                        <td>${p.estado}</td>
                        <td>
                            ${p.detalles.map(d => `${d.producto_nombre} x${d.cantidad} ($${d.precio_unitario})`).join('<br>')}
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    container.innerHTML = table;
}


}

// Inicializar la aplicación cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    window.adminApp = new AdminApp();
});


