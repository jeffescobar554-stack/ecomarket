const db = require('../config/database');

module.exports = {

    getAll: (callback) => {
        const sql = `
            SELECT 
                p.id_pedido,
                p.id_cliente,
                p.fecha,
                p.estado,
                c.nombre AS cliente_nombre
            FROM pedidos p
            LEFT JOIN clientes c ON p.id_cliente = c.id_cliente
            ORDER BY p.fecha DESC
        `;
        db.query(sql, callback);
    },

    getDetalles: (id_pedido, callback) => {
        const sql = `
            SELECT 
                dp.id,
                dp.id_producto,
                pr.nombre AS producto_nombre,
                dp.cantidad,
                dp.precio_unitario
            FROM detalles_pedido dp
            LEFT JOIN productos pr ON dp.id_producto = pr.id_producto
            WHERE dp.id_pedido = ?
        `;
        db.query(sql, [id_pedido], callback);
    }

};
