const db = require('../config/database');

function crearPedido(total, callback) {
  const sql = 'INSERT INTO pedidos (fecha, total, tipo_suscripcion) VALUES (NOW(), ?, "ninguna")';
  db.query(sql, [total], (err, result) => {
    if (err) return callback(err);
    callback(null, result.insertId);
  });
}

module.exports = { crearPedido };
