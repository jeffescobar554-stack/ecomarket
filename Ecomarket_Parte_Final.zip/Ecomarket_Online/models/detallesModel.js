const db = require('../config/database');

function agregarDetalle(pedidoId, productoId, cantidad, precio, callback) {
  const sql = 'INSERT INTO detalles_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)';
  db.query(sql, [pedidoId, productoId, cantidad, precio], (err, result) => {
    if (err) return callback(err);
    callback(null, result.insertId);
  });
}

module.exports = { agregarDetalle };
