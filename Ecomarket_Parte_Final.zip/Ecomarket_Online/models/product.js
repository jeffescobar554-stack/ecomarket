// models/product.js
const db = require('../config/database');

const Product = {
  // devuelve todos los productos con aliases para compatibilidad
  async findAll() {
    const sql = `
      SELECT
        id_producto AS id,
        id_categoria AS categoria,
        nombre,
        descripcion,
        precio,
        stock,
        unidad_medida,
        imagen_url AS imagen,
        es_organico,
        activo,
        fecha_agregado
      FROM productos
      WHERE activo = 1
      ORDER BY nombre
    `;
    const [rows] = await db.promise().query(sql);
    return rows;
  },

  async findById(id) {
    const sql = `
      SELECT
        id_producto AS id,
        id_categoria AS categoria,
        nombre,
        descripcion,
        precio,
        stock,
        unidad_medida,
        imagen_url AS imagen,
        es_organico,
        activo,
        fecha_agregado
      FROM productos
      WHERE id_producto = ? AND activo = 1
      LIMIT 1
    `;
    const [rows] = await db.promise().query(sql, [id]);
    return rows[0];
  },

  async create({ nombre, id_categoria, descripcion, precio, stock, unidad_medida, imagen_url, es_organico }) {
    const sql = `
      INSERT INTO productos
        (id_categoria, nombre, descripcion, precio, stock, unidad_medida, imagen_url, es_organico)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const [result] = await db.promise().query(sql, [
      id_categoria || null,
      nombre,
      descripcion || null,
      precio || 0.00,
      stock || 0,
      unidad_medida || null,
      imagen_url || null,
      es_organico ? 1 : 0
    ]);
    return { id: result.insertId };
  }
};

module.exports = Product;
