const db = require('./config/database');
const bcrypt = require('bcryptjs');

async function updateAdminPassword() {
    try {
        const newPassword = '123456'; // ¡Pon la que quieras!
        const password_hash = await bcrypt.hash(newPassword, 10);

        const query = 'UPDATE usuarios SET password_hash = ? WHERE email = ?';
        
        db.execute(query, [password_hash, 'admin@ecomarket.com'], (err, results) => {
            if (err) {
                console.error('Error actualizando contraseña:', err);
            } else {
                console.log('✅ Contraseña de admin actualizada exitosamente!');
                console.log('📧 Email: admin@ecomarket.com');
                console.log('🔐 Nueva contraseña: ' + newPassword);
            }
            process.exit();
        });
    } catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
}

updateAdminPassword();