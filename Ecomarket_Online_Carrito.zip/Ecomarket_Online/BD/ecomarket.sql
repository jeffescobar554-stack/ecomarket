-- Crear base de datos
CREATE DATABASE ecomarket_online;
USE ecomarket_online;

-- Tabla de productores
CREATE TABLE productores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    tipo_producto VARCHAR(100),
    ubicacion VARCHAR(150)
);

-- Tabla de productos
CREATE TABLE productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    categoria VARCHAR(100),
    precio DECIMAL(10,2),
    stock INT,
    productor_id INT,
    FOREIGN KEY (productor_id) REFERENCES productores(id)
);

-- Tabla de clientes
CREATE TABLE clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    correo VARCHAR(100),
    telefono VARCHAR(20),
    segmento VARCHAR(100)
);

-- Tabla de pedidos
CREATE TABLE pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT,
    fecha DATE,
    total DECIMAL(10,2),
    tipo_suscripcion ENUM('ninguna','semanal','mensual'),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- Tabla de detalles de pedido
CREATE TABLE detalles_pedido (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pedido_id INT,
    producto_id INT,
    cantidad INT,
    precio_unitario DECIMAL(10,2),
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
    FOREIGN KEY (producto_id) REFERENCES productos(id)
);

-- Tabla de alianzas (asociaciones clave)
CREATE TABLE alianzas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    tipo ENUM('productor','logística','empaque','nutriólogo','chef','cafetería'),
    descripcion TEXT
);

-- Tabla de canales
CREATE TABLE canales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    tipo ENUM('web','app','red_social','evento','publicidad'),
    descripcion TEXT
);

-- Tabla de recursos clave
CREATE TABLE recursos_clave (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    descripcion TEXT
);

-- Tabla de actividades clave
CREATE TABLE actividades_clave (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    descripcion TEXT
);

-- Tabla de fuentes de ingresos
CREATE TABLE fuentes_ingresos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(100),
    descripcion TEXT
);

-- Tabla de estructura de costos
CREATE TABLE estructura_costos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    categoria VARCHAR(100),
    descripcion TEXT
);
