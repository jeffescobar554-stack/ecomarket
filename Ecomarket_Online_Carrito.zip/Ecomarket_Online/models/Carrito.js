const db = require('../config/database');

class Carrito {
  static getByUserId(id_usuario) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT c.*, p.nombre, p.precio, p.stock, p.imagen_url, p.unidad_medida
        FROM carrito c
        INNER JOIN productos p ON c.id_producto = p.id_producto
        WHERE c.id_usuario = ?
      `;
      db.execute(query, [id_usuario], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static addItem(carritoData) {
    return new Promise((resolve, reject) => {
      const query = `
        INSERT INTO carrito (id_usuario, id_producto, cantidad) 
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE cantidad = cantidad + VALUES(cantidad)
      `;
      const { id_usuario, id_producto, cantidad } = carritoData;
      
      db.execute(query, [id_usuario, id_producto, cantidad], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static updateItem(id_usuario, id_producto, cantidad) {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE carrito SET cantidad = ? WHERE id_usuario = ? AND id_producto = ?';
      db.execute(query, [cantidad, id_usuario, id_producto], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static removeItem(id_usuario, id_producto) {
    return new Promise((resolve, reject) => {
      const query = 'DELETE FROM carrito WHERE id_usuario = ? AND id_producto = ?';
      db.execute(query, [id_usuario, id_producto], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static clearUserCart(id_usuario) {
    return new Promise((resolve, reject) => {
      const query = 'DELETE FROM carrito WHERE id_usuario = ?';
      db.execute(query, [id_usuario], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }
}

module.exports = Carrito;