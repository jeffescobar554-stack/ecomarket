const db = require('../config/database');

class Direccion {
  static getByClienteId(id_cliente) {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM direcciones WHERE id_cliente = ? ORDER BY es_principal DESC';
      db.execute(query, [id_cliente], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM direcciones WHERE id_direccion = ?';
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results[0]);
      });
    });
  }

  static create(direccionData) {
    return new Promise((resolve, reject) => {
      // Si es principal, quitar principal de otras direcciones
      if (direccionData.es_principal) {
        const updateQuery = 'UPDATE direcciones SET es_principal = FALSE WHERE id_cliente = ?';
        db.execute(updateQuery, [direccionData.id_cliente]);
      }

      const query = `
        INSERT INTO direcciones 
        (id_cliente, calle, numero_exterior, numero_interior, colonia, ciudad, estado, codigo_postal, referencias, es_principal) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      const { id_cliente, calle, numero_exterior, numero_interior, colonia, ciudad, estado, codigo_postal, referencias, es_principal } = direccionData;
      
      db.execute(query, [
        id_cliente, calle, numero_exterior, numero_interior, colonia, ciudad, estado, codigo_postal, referencias, es_principal
      ], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static update(id, direccionData) {
    return new Promise((resolve, reject) => {
      // Si es principal, quitar principal de otras direcciones
      if (direccionData.es_principal) {
        const updateQuery = 'UPDATE direcciones SET es_principal = FALSE WHERE id_cliente = ? AND id_direccion != ?';
        db.execute(updateQuery, [direccionData.id_cliente, id]);
      }

      const query = `
        UPDATE direcciones 
        SET calle = ?, numero_exterior = ?, numero_interior = ?, colonia = ?, ciudad = ?, estado = ?, 
            codigo_postal = ?, referencias = ?, es_principal = ? 
        WHERE id_direccion = ?
      `;
      const { calle, numero_exterior, numero_interior, colonia, ciudad, estado, codigo_postal, referencias, es_principal } = direccionData;
      
      db.execute(query, [
        calle, numero_exterior, numero_interior, colonia, ciudad, estado, codigo_postal, referencias, es_principal, id
      ], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      const query = 'DELETE FROM direcciones WHERE id_direccion = ?';
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }
}

module.exports = Direccion;