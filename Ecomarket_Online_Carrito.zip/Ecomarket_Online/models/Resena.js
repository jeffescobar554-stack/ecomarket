const db = require('../config/database');

class Resena {
  static getAll() {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT r.*, p.nombre as producto_nombre, u.email as usuario_email
        FROM resenas r
        INNER JOIN productos p ON r.id_producto = p.id_producto
        INNER JOIN usuarios u ON r.id_usuario = u.id_usuario
        ORDER BY r.fecha_resena DESC
      `;
      db.execute(query, (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static getByProductoId(id_producto) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT r.*, u.email as usuario_email
        FROM resenas r
        INNER JOIN usuarios u ON r.id_usuario = u.id_usuario
        WHERE r.id_producto = ?
        ORDER BY r.fecha_resena DESC
      `;
      db.execute(query, [id_producto], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static create(resenaData) {
    return new Promise((resolve, reject) => {
      const query = `
        INSERT INTO resenas 
        (id_producto, id_usuario, calificacion, comentario) 
        VALUES (?, ?, ?, ?)
      `;
      const { id_producto, id_usuario, calificacion, comentario } = resenaData;
      
      db.execute(query, [id_producto, id_usuario, calificacion, comentario], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static update(id, resenaData) {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE resenas SET calificacion = ?, comentario = ? WHERE id_resena = ?';
      const { calificacion, comentario } = resenaData;
      
      db.execute(query, [calificacion, comentario, id], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      const query = 'DELETE FROM resenas WHERE id_resena = ?';
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }
}

module.exports = Resena;