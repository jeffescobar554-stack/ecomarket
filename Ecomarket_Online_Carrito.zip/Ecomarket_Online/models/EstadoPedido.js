const db = require('../config/database');

class EstadoPedido {
  static getAll() {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM estados_pedido ORDER BY id_estado';
      db.execute(query, (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM estados_pedido WHERE id_estado = ?';
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results[0]);
      });
    });
  }

  static create(estadoData) {
    return new Promise((resolve, reject) => {
      const query = 'INSERT INTO estados_pedido (nombre, descripcion) VALUES (?, ?)';
      const { nombre, descripcion } = estadoData;
      
      db.execute(query, [nombre, descripcion], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static update(id, estadoData) {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE estados_pedido SET nombre = ?, descripcion = ? WHERE id_estado = ?';
      const { nombre, descripcion } = estadoData;
      
      db.execute(query, [nombre, descripcion, id], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      const query = 'DELETE FROM estados_pedido WHERE id_estado = ?';
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }
}

module.exports = EstadoPedido;