const db = require('../config/database');

class Pedido {
  static getAll() {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT p.*, 
               CONCAT(c.nombre, ' ', c.apellido_paterno) as cliente_nombre,
               e.nombre as estado_nombre,
               m.nombre as metodo_pago_nombre
        FROM pedidos p
        INNER JOIN usuarios u ON p.id_usuario = u.id_usuario
        INNER JOIN clientes c ON u.id_usuario = c.id_usuario
        INNER JOIN estados_pedido e ON p.id_estado = e.id_estado
        INNER JOIN metodos_pago m ON p.id_metodo_pago = m.id_metodo_pago
        ORDER BY p.fecha_pedido DESC
      `;
      db.execute(query, (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT p.*, 
               CONCAT(c.nombre, ' ', c.apellido_paterno) as cliente_nombre,
               e.nombre as estado_nombre,
               m.nombre as metodo_pago_nombre
        FROM pedidos p
        INNER JOIN usuarios u ON p.id_usuario = u.id_usuario
        INNER JOIN clientes c ON u.id_usuario = c.id_usuario
        INNER JOIN estados_pedido e ON p.id_estado = e.id_estado
        INNER JOIN metodos_pago m ON p.id_metodo_pago = m.id_metodo_pago
        WHERE p.id_pedido = ?
      `;
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results[0]);
      });
    });
  }

  static getByUserId(id_usuario) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT p.*, e.nombre as estado_nombre
        FROM pedidos p
        INNER JOIN estados_pedido e ON p.id_estado = e.id_estado
        WHERE p.id_usuario = ?
        ORDER BY p.fecha_pedido DESC
      `;
      db.execute(query, [id_usuario], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static create(pedidoData) {
    return new Promise((resolve, reject) => {
      const query = `
        INSERT INTO pedidos 
        (id_usuario, id_direccion, id_estado, id_metodo_pago, numero_pedido, subtotal, costo_envio, total, fecha_entrega_estimada, notas) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      const { id_usuario, id_direccion, id_estado, id_metodo_pago, numero_pedido, subtotal, costo_envio, total, fecha_entrega_estimada, notas } = pedidoData;
      
      db.execute(query, [
        id_usuario, id_direccion, id_estado, id_metodo_pago, numero_pedido, subtotal, costo_envio, total, fecha_entrega_estimada, notas
      ], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static update(id, pedidoData) {
    return new Promise((resolve, reject) => {
      const query = `
        UPDATE pedidos 
        SET id_estado = ?, fecha_entrega_real = ?, notas = ? 
        WHERE id_pedido = ?
      `;
      const { id_estado, fecha_entrega_real, notas } = pedidoData;
      
      db.execute(query, [id_estado, fecha_entrega_real, notas, id], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      const query = 'DELETE FROM pedidos WHERE id_pedido = ?';
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }
}

module.exports = Pedido;