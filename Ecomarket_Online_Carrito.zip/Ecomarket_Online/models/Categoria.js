const db = require('../config/database');

class Categoria {
  static getAll() {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM categorias WHERE activa = TRUE ORDER BY nombre';
      db.execute(query, (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM categorias WHERE id_categoria = ?';
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results[0]);
      });
    });
  }

  static create(categoriaData) {
    return new Promise((resolve, reject) => {
      const query = 'INSERT INTO categorias (nombre, descripcion, imagen_url) VALUES (?, ?, ?)';
      const { nombre, descripcion, imagen_url } = categoriaData;
      db.execute(query, [nombre, descripcion, imagen_url], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static update(id, categoriaData) {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE categorias SET nombre = ?, descripcion = ?, imagen_url = ? WHERE id_categoria = ?';
      const { nombre, descripcion, imagen_url } = categoriaData;
      db.execute(query, [nombre, descripcion, imagen_url, id], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE categorias SET activa = FALSE WHERE id_categoria = ?';
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }
}

module.exports = Categoria;