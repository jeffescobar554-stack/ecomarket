const db = require('../config/database');

class Producto {
  static getAll() {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT p.*, c.nombre as categoria_nombre 
        FROM productos p 
        INNER JOIN categorias c ON p.id_categoria = c.id_categoria 
        WHERE p.activo = TRUE 
        ORDER BY p.nombre
      `;
      db.execute(query, (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT p.*, c.nombre as categoria_nombre 
        FROM productos p 
        INNER JOIN categorias c ON p.id_categoria = c.id_categoria 
        WHERE p.id_producto = ?
      `;
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results[0]);
      });
    });
  }

  static create(productoData) {
    return new Promise((resolve, reject) => {
      const query = `
        INSERT INTO productos 
        (id_categoria, nombre, descripcion, precio, stock, unidad_medida, imagen_url, es_organico, ingredientes, informacion_nutricional) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      const { id_categoria, nombre, descripcion, precio, stock, unidad_medida, imagen_url, es_organico, ingredientes, informacion_nutricional } = productoData;
      
      db.execute(query, [
        id_categoria, nombre, descripcion, precio, stock, unidad_medida, 
        imagen_url, es_organico, ingredientes, informacion_nutricional
      ], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static update(id, productoData) {
    return new Promise((resolve, reject) => {
      const query = `
        UPDATE productos 
        SET id_categoria = ?, nombre = ?, descripcion = ?, precio = ?, stock = ?, 
            unidad_medida = ?, imagen_url = ?, es_organico = ?, ingredientes = ?, 
            informacion_nutricional = ? 
        WHERE id_producto = ?
      `;
      const { id_categoria, nombre, descripcion, precio, stock, unidad_medida, imagen_url, es_organico, ingredientes, informacion_nutricional } = productoData;
      
      db.execute(query, [
        id_categoria, nombre, descripcion, precio, stock, unidad_medida, 
        imagen_url, es_organico, ingredientes, informacion_nutricional, id
      ], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

// En models/Producto.js - para eliminación permanente
static delete(id) {
    return new Promise((resolve, reject) => {
        const query = 'DELETE FROM productos WHERE id_producto = ?';
        db.execute(query, [id], (err, results) => {
            if (err) reject(err);
            resolve(results);
        });
    });
}
// Y agregar este método para obtener solo productos activos
static getAllActive() {
    return new Promise((resolve, reject) => {
        const query = `
            SELECT p.*, c.nombre as categoria_nombre 
            FROM productos p 
            INNER JOIN categorias c ON p.id_categoria = c.id_categoria 
            WHERE p.activo = TRUE 
            ORDER BY p.nombre
        `;
        db.execute(query, (err, results) => {
            if (err) reject(err);
            resolve(results);
        });
    });
}


}

module.exports = Producto;