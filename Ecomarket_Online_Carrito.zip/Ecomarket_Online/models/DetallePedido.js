const db = require('../config/database');

class DetallePedido {
  static getByPedidoId(id_pedido) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT d.*, p.nombre as producto_nombre, p.imagen_url
        FROM detalle_pedidos d
        INNER JOIN productos p ON d.id_producto = p.id_producto
        WHERE d.id_pedido = ?
      `;
      db.execute(query, [id_pedido], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static create(detalleData) {
    return new Promise((resolve, reject) => {
      const query = `
        INSERT INTO detalle_pedidos 
        (id_pedido, id_producto, cantidad, precio_unitario, subtotal) 
        VALUES (?, ?, ?, ?, ?)
      `;
      const { id_pedido, id_producto, cantidad, precio_unitario, subtotal } = detalleData;
      
      db.execute(query, [id_pedido, id_producto, cantidad, precio_unitario, subtotal], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }
}

module.exports = DetallePedido;