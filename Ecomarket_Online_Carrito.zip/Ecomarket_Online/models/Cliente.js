const db = require('../config/database');

class Cliente {
  static getAll() {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT c.*, u.email, u.fecha_registro, u.activo 
        FROM clientes c 
        INNER JOIN usuarios u ON c.id_usuario = u.id_usuario 
        ORDER BY c.nombre
      `;
      db.execute(query, (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const query = `
        SELECT c.*, u.email, u.fecha_registro, u.activo 
        FROM clientes c 
        INNER JOIN usuarios u ON c.id_usuario = u.id_usuario 
        WHERE c.id_cliente = ?
      `;
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results[0]);
      });
    });
  }

  static getByUserId(id_usuario) {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM clientes WHERE id_usuario = ?';
      db.execute(query, [id_usuario], (err, results) => {
        if (err) reject(err);
        resolve(results[0]);
      });
    });
  }

  static create(clienteData) {
    return new Promise((resolve, reject) => {
      const query = `
        INSERT INTO clientes 
        (id_usuario, nombre, apellido_paterno, apellido_materno, telefono, fecha_nacimiento) 
        VALUES (?, ?, ?, ?, ?, ?)
      `;
      const { id_usuario, nombre, apellido_paterno, apellido_materno, telefono, fecha_nacimiento } = clienteData;
      
      db.execute(query, [
        id_usuario, nombre, apellido_paterno, apellido_materno, telefono, fecha_nacimiento
      ], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static update(id, clienteData) {
    return new Promise((resolve, reject) => {
      const query = `
        UPDATE clientes 
        SET nombre = ?, apellido_paterno = ?, apellido_materno = ?, telefono = ?, fecha_nacimiento = ? 
        WHERE id_cliente = ?
      `;
      const { nombre, apellido_paterno, apellido_materno, telefono, fecha_nacimiento } = clienteData;
      
      db.execute(query, [
        nombre, apellido_paterno, apellido_materno, telefono, fecha_nacimiento, id
      ], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      const query = 'DELETE FROM clientes WHERE id_cliente = ?';
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }
}

module.exports = Cliente;