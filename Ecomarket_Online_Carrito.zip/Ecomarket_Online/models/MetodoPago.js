const db = require('../config/database');

class MetodoPago {
  static getAll() {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM metodos_pago WHERE activo = TRUE ORDER BY nombre';
      db.execute(query, (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM metodos_pago WHERE id_metodo_pago = ?';
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results[0]);
      });
    });
  }

  static create(metodoData) {
    return new Promise((resolve, reject) => {
      const query = 'INSERT INTO metodos_pago (nombre) VALUES (?)';
      const { nombre } = metodoData;
      
      db.execute(query, [nombre], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static update(id, metodoData) {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE metodos_pago SET nombre = ? WHERE id_metodo_pago = ?';
      const { nombre } = metodoData;
      
      db.execute(query, [nombre, id], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE metodos_pago SET activo = FALSE WHERE id_metodo_pago = ?';
      db.execute(query, [id], (err, results) => {
        if (err) reject(err);
        resolve(results);
      });
    });
  }
}

module.exports = MetodoPago;