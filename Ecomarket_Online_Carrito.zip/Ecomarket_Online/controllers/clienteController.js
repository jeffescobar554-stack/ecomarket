const Cliente = require('../models/Cliente');

const getAllClientes = async (req, res) => {
  try {
    const clientes = await Cliente.getAll();
    res.json(clientes);
  } catch (error) {
    console.error('Error obteniendo clientes:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const getClienteById = async (req, res) => {
  try {
    const { id } = req.params;
    const cliente = await Cliente.getById(id);
    
    if (!cliente) {
      return res.status(404).json({ error: 'Cliente no encontrado' });
    }
    
    res.json(cliente);
  } catch (error) {
    console.error('Error obteniendo cliente:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const createCliente = async (req, res) => {
  try {
    const clienteData = req.body;
    
    if (!clienteData.nombre || !clienteData.apellido_paterno || !clienteData.telefono) {
      return res.status(400).json({ error: 'Nombre, apellido paterno y teléfono son requeridos' });
    }

    const result = await Cliente.create(clienteData);
    res.status(201).json({ 
      message: 'Cliente creado exitosamente', 
      id: result.insertId 
    });
  } catch (error) {
    console.error('Error creando cliente:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const updateCliente = async (req, res) => {
  try {
    const { id } = req.params;
    const clienteData = req.body;
    
    if (!clienteData.nombre || !clienteData.apellido_paterno || !clienteData.telefono) {
      return res.status(400).json({ error: 'Nombre, apellido paterno y teléfono son requeridos' });
    }

    await Cliente.update(id, clienteData);
    res.json({ message: 'Cliente actualizado exitosamente' });
  } catch (error) {
    console.error('Error actualizando cliente:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const deleteCliente = async (req, res) => {
  try {
    const { id } = req.params;
    await Cliente.delete(id);
    res.json({ message: 'Cliente eliminado exitosamente' });
  } catch (error) {
    console.error('Error eliminando cliente:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

module.exports = {
  getAllClientes,
  getClienteById,
  createCliente,
  updateCliente,
  deleteCliente
};