const MetodoPago = require('../models/MetodoPago');

const getAllMetodos = async (req, res) => {
  try {
    const metodos = await MetodoPago.getAll();
    res.json(metodos);
  } catch (error) {
    console.error('Error obteniendo métodos de pago:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const createMetodo = async (req, res) => {
  try {
    const { nombre } = req.body;
    
    if (!nombre) {
      return res.status(400).json({ error: 'El nombre es requerido' });
    }

    const result = await MetodoPago.create({ nombre });
    res.status(201).json({ 
      message: 'Método de pago creado exitosamente', 
      id: result.insertId 
    });
  } catch (error) {
    console.error('Error creando método de pago:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const updateMetodo = async (req, res) => {
  try {
    const { id } = req.params;
    const { nombre } = req.body;
    
    if (!nombre) {
      return res.status(400).json({ error: 'El nombre es requerido' });
    }

    await MetodoPago.update(id, { nombre });
    res.json({ message: 'Método de pago actualizado exitosamente' });
  } catch (error) {
    console.error('Error actualizando método de pago:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const deleteMetodo = async (req, res) => {
  try {
    const { id } = req.params;
    await MetodoPago.delete(id);
    res.json({ message: 'Método de pago eliminado exitosamente' });
  } catch (error) {
    console.error('Error eliminando método de pago:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

module.exports = {
  getAllMetodos,
  createMetodo,
  updateMetodo,
  deleteMetodo
};