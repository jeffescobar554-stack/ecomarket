const Direccion = require('../models/Direccion');

const getDireccionesByCliente = async (req, res) => {
  try {
    const { clienteId } = req.params;
    const direcciones = await Direccion.getByClienteId(clienteId);
    res.json(direcciones);
  } catch (error) {
    console.error('Error obteniendo direcciones:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const createDireccion = async (req, res) => {
  try {
    const direccionData = req.body;
    
    if (!direccionData.calle || !direccionData.numero_exterior || !direccionData.colonia || 
        !direccionData.ciudad || !direccionData.estado || !direccionData.codigo_postal) {
      return res.status(400).json({ error: 'Todos los campos obligatorios son requeridos' });
    }

    const result = await Direccion.create(direccionData);
    res.status(201).json({ 
      message: 'Dirección creada exitosamente', 
      id: result.insertId 
    });
  } catch (error) {
    console.error('Error creando dirección:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const updateDireccion = async (req, res) => {
  try {
    const { id } = req.params;
    const direccionData = req.body;
    
    if (!direccionData.calle || !direccionData.numero_exterior || !direccionData.colonia || 
        !direccionData.ciudad || !direccionData.estado || !direccionData.codigo_postal) {
      return res.status(400).json({ error: 'Todos los campos obligatorios son requeridos' });
    }

    await Direccion.update(id, direccionData);
    res.json({ message: 'Dirección actualizada exitosamente' });
  } catch (error) {
    console.error('Error actualizando dirección:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const deleteDireccion = async (req, res) => {
  try {
    const { id } = req.params;
    await Direccion.delete(id);
    res.json({ message: 'Dirección eliminada exitosamente' });
  } catch (error) {
    console.error('Error eliminando dirección:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

module.exports = {
  getDireccionesByCliente,
  createDireccion,
  updateDireccion,
  deleteDireccion
};