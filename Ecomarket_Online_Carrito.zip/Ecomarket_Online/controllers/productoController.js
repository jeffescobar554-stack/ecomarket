const Producto = require('../models/Producto');

const getAllProductos = async (req, res) => {
    try {
        const productos = await Producto.getAllActive(); // Cambiar por getAllActive
        res.json(productos);
    } catch (error) {
        console.error('Error obteniendo productos:', error);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
};

const getProductoById = async (req, res) => {
  try {
    const { id } = req.params;
    const producto = await Producto.getById(id);
    
    if (!producto) {
      return res.status(404).json({ error: 'Producto no encontrado' });
    }
    
    res.json(producto);
  } catch (error) {
    console.error('Error obteniendo producto:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const createProducto = async (req, res) => {
  try {
    const productoData = req.body;
    
    // Validaciones básicas
    if (!productoData.nombre || !productoData.precio || !productoData.id_categoria) {
      return res.status(400).json({ error: 'Nombre, precio y categoría son requeridos' });
    }

    const result = await Producto.create(productoData);
    res.status(201).json({ 
      message: 'Producto creado exitosamente', 
      id: result.insertId 
    });
  } catch (error) {
    console.error('Error creando producto:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const updateProducto = async (req, res) => {
  try {
    const { id } = req.params;
    const productoData = req.body;
    
    if (!productoData.nombre || !productoData.precio || !productoData.id_categoria) {
      return res.status(400).json({ error: 'Nombre, precio y categoría son requeridos' });
    }

    await Producto.update(id, productoData);
    res.json({ message: 'Producto actualizado exitosamente' });
  } catch (error) {
    console.error('Error actualizando producto:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const deleteProducto = async (req, res) => {
  try {
    const { id } = req.params;
    await Producto.delete(id);
    res.json({ message: 'Producto eliminado exitosamente' });
  } catch (error) {
    console.error('Error eliminando producto:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

module.exports = {
  getAllProductos,
  getProductoById,
  createProducto,
  updateProducto,
  deleteProducto
};