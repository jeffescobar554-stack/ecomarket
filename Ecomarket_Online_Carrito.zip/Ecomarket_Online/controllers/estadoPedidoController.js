const EstadoPedido = require('../models/EstadoPedido');

const getAllEstados = async (req, res) => {
  try {
    const estados = await EstadoPedido.getAll();
    res.json(estados);
  } catch (error) {
    console.error('Error obteniendo estados de pedido:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const createEstado = async (req, res) => {
  try {
    const { nombre, descripcion } = req.body;
    
    if (!nombre) {
      return res.status(400).json({ error: 'El nombre es requerido' });
    }

    const result = await EstadoPedido.create({ nombre, descripcion });
    res.status(201).json({ 
      message: 'Estado de pedido creado exitosamente', 
      id: result.insertId 
    });
  } catch (error) {
    console.error('Error creando estado de pedido:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const updateEstado = async (req, res) => {
  try {
    const { id } = req.params;
    const { nombre, descripcion } = req.body;
    
    if (!nombre) {
      return res.status(400).json({ error: 'El nombre es requerido' });
    }

    await EstadoPedido.update(id, { nombre, descripcion });
    res.json({ message: 'Estado de pedido actualizado exitosamente' });
  } catch (error) {
    console.error('Error actualizando estado de pedido:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const deleteEstado = async (req, res) => {
  try {
    const { id } = req.params;
    await EstadoPedido.delete(id);
    res.json({ message: 'Estado de pedido eliminado exitosamente' });
  } catch (error) {
    console.error('Error eliminando estado de pedido:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

module.exports = {
  getAllEstados,
  createEstado,
  updateEstado,
  deleteEstado
};