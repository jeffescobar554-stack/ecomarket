const Pedido = require('../models/Pedido');
const DetallePedido = require('../models/DetallePedido');

const getAllPedidos = async (req, res) => {
  try {
    const pedidos = await Pedido.getAll();
    res.json(pedidos);
  } catch (error) {
    console.error('Error obteniendo pedidos:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const getPedidoById = async (req, res) => {
  try {
    const { id } = req.params;
    const pedido = await Pedido.getById(id);
    
    if (!pedido) {
      return res.status(404).json({ error: 'Pedido no encontrado' });
    }

    // Obtener detalles del pedido
    const detalles = await DetallePedido.getByPedidoId(id);
    pedido.detalles = detalles;
    
    res.json(pedido);
  } catch (error) {
    console.error('Error obteniendo pedido:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const createPedido = async (req, res) => {
  try {
    const pedidoData = req.body;
    
    // Validaciones básicas
    if (!pedidoData.id_usuario || !pedidoData.id_direccion || !pedidoData.id_metodo_pago) {
      return res.status(400).json({ error: 'Datos incompletos para crear el pedido' });
    }

    // Generar número de pedido único
    const numero_pedido = 'PED' + Date.now();
    pedidoData.numero_pedido = numero_pedido;

    const result = await Pedido.create(pedidoData);
    res.status(201).json({ 
      message: 'Pedido creado exitosamente', 
      id: result.insertId,
      numero_pedido: numero_pedido
    });
  } catch (error) {
    console.error('Error creando pedido:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const updatePedido = async (req, res) => {
  try {
    const { id } = req.params;
    const pedidoData = req.body;

    await Pedido.update(id, pedidoData);
    res.json({ message: 'Pedido actualizado exitosamente' });
  } catch (error) {
    console.error('Error actualizando pedido:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const deletePedido = async (req, res) => {
  try {
    const { id } = req.params;
    await Pedido.delete(id);
    res.json({ message: 'Pedido eliminado exitosamente' });
  } catch (error) {
    console.error('Error eliminando pedido:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

module.exports = {
  getAllPedidos,
  getPedidoById,
  createPedido,
  updatePedido,
  deletePedido
};