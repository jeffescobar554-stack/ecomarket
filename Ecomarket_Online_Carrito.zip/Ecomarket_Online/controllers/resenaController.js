const Resena = require('../models/Resena');

const getAllResenas = async (req, res) => {
  try {
    const resenas = await Resena.getAll();
    res.json(resenas);
  } catch (error) {
    console.error('Error obteniendo reseñas:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const getResenasByProducto = async (req, res) => {
  try {
    const { productoId } = req.params;
    const resenas = await Resena.getByProductoId(productoId);
    res.json(resenas);
  } catch (error) {
    console.error('Error obteniendo reseñas:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const createResena = async (req, res) => {
  try {
    const resenaData = req.body;
    
    if (!resenaData.id_producto || !resenaData.id_usuario || !resenaData.calificacion) {
      return res.status(400).json({ error: 'Producto, usuario y calificación son requeridos' });
    }

    if (resenaData.calificacion < 1 || resenaData.calificacion > 5) {
      return res.status(400).json({ error: 'La calificación debe estar entre 1 y 5' });
    }

    const result = await Resena.create(resenaData);
    res.status(201).json({ 
      message: 'Reseña creada exitosamente', 
      id: result.insertId 
    });
  } catch (error) {
    console.error('Error creando reseña:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const updateResena = async (req, res) => {
  try {
    const { id } = req.params;
    const resenaData = req.body;

    if (resenaData.calificacion && (resenaData.calificacion < 1 || resenaData.calificacion > 5)) {
      return res.status(400).json({ error: 'La calificación debe estar entre 1 y 5' });
    }

    await Resena.update(id, resenaData);
    res.json({ message: 'Reseña actualizada exitosamente' });
  } catch (error) {
    console.error('Error actualizando reseña:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const deleteResena = async (req, res) => {
  try {
    const { id } = req.params;
    await Resena.delete(id);
    res.json({ message: 'Reseña eliminada exitosamente' });
  } catch (error) {
    console.error('Error eliminando reseña:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

module.exports = {
  getAllResenas,
  getResenasByProducto,
  createResena,
  updateResena,
  deleteResena
};