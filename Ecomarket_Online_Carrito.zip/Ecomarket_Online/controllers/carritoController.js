const Carrito = require('../models/Carrito');

const getCarritoByUser = async (req, res) => {
  try {
    const { usuarioId } = req.params;
    const carrito = await Carrito.getByUserId(usuarioId);
    res.json(carrito);
  } catch (error) {
    console.error('Error obteniendo carrito:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const addToCarrito = async (req, res) => {
  try {
    const carritoData = req.body;
    
    if (!carritoData.id_usuario || !carritoData.id_producto || !carritoData.cantidad) {
      return res.status(400).json({ error: 'Usuario, producto y cantidad son requeridos' });
    }

    await Carrito.addItem(carritoData);
    res.json({ message: 'Producto agregado al carrito exitosamente' });
  } catch (error) {
    console.error('Error agregando al carrito:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const updateCarritoItem = async (req, res) => {
  try {
    const { usuarioId, productoId } = req.params;
    const { cantidad } = req.body;

    if (!cantidad || cantidad < 1) {
      return res.status(400).json({ error: 'La cantidad debe ser mayor a 0' });
    }

    await Carrito.updateItem(usuarioId, productoId, cantidad);
    res.json({ message: 'Carrito actualizado exitosamente' });
  } catch (error) {
    console.error('Error actualizando carrito:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const removeFromCarrito = async (req, res) => {
  try {
    const { usuarioId, productoId } = req.params;
    await Carrito.removeItem(usuarioId, productoId);
    res.json({ message: 'Producto eliminado del carrito exitosamente' });
  } catch (error) {
    console.error('Error eliminando del carrito:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const clearCarrito = async (req, res) => {
  try {
    const { usuarioId } = req.params;
    await Carrito.clearUserCart(usuarioId);
    res.json({ message: 'Carrito vaciado exitosamente' });
  } catch (error) {
    console.error('Error vaciando carrito:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

module.exports = {
  getCarritoByUser,
  addToCarrito,
  updateCarritoItem,
  removeFromCarrito,
  clearCarrito
};  