const express = require('express');
const { 
  getAllMetodos, 
  createMetodo, 
  updateMetodo, 
  deleteMetodo 
} = require('../controllers/metodoPagoController');
const { adminAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/', getAllMetodos);
router.post('/', adminAuth, createMetodo);
router.put('/:id', adminAuth, updateMetodo);
router.delete('/:id', adminAuth, deleteMetodo);

module.exports = router;