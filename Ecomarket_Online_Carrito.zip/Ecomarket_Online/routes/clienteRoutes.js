const express = require('express');
const { 
  getAllClientes, 
  getClienteById, 
  createCliente, 
  updateCliente, 
  deleteCliente 
} = require('../controllers/clienteController');
const { adminAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/', adminAuth, getAllClientes);
router.get('/:id', adminAuth, getClienteById);
router.post('/', adminAuth, createCliente);
router.put('/:id', adminAuth, updateCliente);
router.delete('/:id', adminAuth, deleteCliente);

module.exports = router;