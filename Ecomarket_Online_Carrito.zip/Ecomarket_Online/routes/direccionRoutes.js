const express = require('express');
const { 
  getDireccionesByCliente, 
  createDireccion, 
  updateDireccion, 
  deleteDireccion 
} = require('../controllers/direccionController');
const { auth } = require('../middleware/auth');

const router = express.Router();

router.get('/cliente/:clienteId', auth, getDireccionesByCliente);
router.post('/', auth, createDireccion);
router.put('/:id', auth, updateDireccion);
router.delete('/:id', auth, deleteDireccion);

module.exports = router;