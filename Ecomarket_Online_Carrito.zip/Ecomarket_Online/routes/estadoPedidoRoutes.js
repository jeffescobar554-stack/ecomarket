const express = require('express');
const { 
  getAllEstados, 
  createEstado, 
  updateEstado, 
  deleteEstado 
} = require('../controllers/estadoPedidoController');
const { adminAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/', getAllEstados);
router.post('/', adminAuth, createEstado);
router.put('/:id', adminAuth, updateEstado);
router.delete('/:id', adminAuth, deleteEstado);

module.exports = router;