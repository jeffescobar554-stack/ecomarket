const express = require('express');
const { 
  getCarritoByUser, 
  addToCarrito, 
  updateCarritoItem, 
  removeFromCarrito, 
  clearCarrito 
} = require('../controllers/carritoController');
const { auth } = require('../middleware/auth');

const router = express.Router();

router.get('/usuario/:usuarioId', auth, getCarritoByUser);
router.post('/', auth, addToCarrito);
router.put('/:usuarioId/:productoId', auth, updateCarritoItem);
router.delete('/:usuarioId/:productoId', auth, removeFromCarrito);
router.delete('/usuario/:usuarioId', auth, clearCarrito);

module.exports = router;