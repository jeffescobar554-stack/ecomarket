const express = require('express');
const { 
  getAllCategorias, 
  getCategoriaById, 
  createCategoria, 
  updateCategoria, 
  deleteCategoria 
} = require('../controllers/categoriaController');
const { adminAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/', getAllCategorias);
router.get('/:id', getCategoriaById);
router.post('/', adminAuth, createCategoria);
router.put('/:id', adminAuth, updateCategoria);
router.delete('/:id', adminAuth, deleteCategoria);

module.exports = router;