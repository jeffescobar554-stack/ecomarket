const express = require('express');
const { 
  getAllProductos, 
  getProductoById, 
  createProducto, 
  updateProducto, 
  deleteProducto 
} = require('../controllers/productoController');
const { adminAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/', getAllProductos);
router.get('/:id', getProductoById);
router.post('/', adminAuth, createProducto);
router.put('/:id', adminAuth, updateProducto);
router.delete('/:id', adminAuth, deleteProducto);

module.exports = router;