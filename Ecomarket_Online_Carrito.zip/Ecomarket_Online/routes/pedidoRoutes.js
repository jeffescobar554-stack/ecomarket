const express = require('express');
const { 
  getAllPedidos, 
  getPedidoById, 
  createPedido, 
  updatePedido, 
  deletePedido 
} = require('../controllers/pedidoController');
const { adminAuth, auth } = require('../middleware/auth');

const router = express.Router();

router.get('/', adminAuth, getAllPedidos);
router.get('/:id', auth, getPedidoById);
router.post('/', auth, createPedido);
router.put('/:id', adminAuth, updatePedido);
router.delete('/:id', adminAuth, deletePedido);

module.exports = router;