const express = require('express');
const { 
  getAllResenas, 
  getResenasByProducto, 
  createResena, 
  updateResena, 
  deleteResena 
} = require('../controllers/resenaController');
const { auth, adminAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/', adminAuth, getAllResenas);
router.get('/producto/:productoId', getResenasByProducto);
router.post('/', auth, createResena);
router.put('/:id', auth, updateResena);
router.delete('/:id', auth, deleteResena);

module.exports = router;