class Auth {
    static getToken() {
        return localStorage.getItem('token');
    }

    static setToken(token) {
        localStorage.setItem('token', token);
    }

    static removeToken() {
        localStorage.removeItem('token');
    }

    static isLoggedIn() {
        return this.getToken() !== null;
    }

    static async makeAuthenticatedRequest(url, options = {}) {
        const token = this.getToken();
        if (!token) {
            window.location.href = '/login';
            return;
        }

        const defaultOptions = {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        };

        const mergedOptions = {
            ...defaultOptions,
            ...options,
            headers: {
                ...defaultOptions.headers,
                ...options.headers
            }
        };

        try {
            const response = await fetch(url, mergedOptions);
            
            if (response.status === 401) {
                this.removeToken();
                window.location.href = '/login';
                return;
            }

            return response;
        } catch (error) {
            console.error('Error en la solicitud:', error);
            throw error;
        }
    }
}

// Manejo del formulario de login
if (document.getElementById('loginForm')) {
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const messageDiv = document.getElementById('message');

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (response.ok) {
                Auth.setToken(data.token);
                messageDiv.textContent = 'Login exitoso! Redirigiendo...';
                messageDiv.className = 'message success';
                
                setTimeout(() => {
                    window.location.href = '/admin';
                }, 1000);
            } else {
                messageDiv.textContent = data.error || 'Error en el login';
                messageDiv.className = 'message error';
            }
        } catch (error) {
            console.error('Error:', error);
            messageDiv.textContent = 'Error de conexión';
            messageDiv.className = 'message error';
        }
    });
}

// Manejo del logout
if (document.getElementById('logoutBtn')) {
    document.getElementById('logoutBtn').addEventListener('click', () => {
        Auth.removeToken();
        window.location.href = '/login';
    });
}

// Verificar autenticación en páginas protegidas
if (window.location.pathname === '/admin' && !Auth.isLoggedIn()) {
    window.location.href = '/login';
}